<html>
    <head>
        <title>@yield('title')</title>
    </head>
    <body>
        @section('sidebar')
        this is parent content  
        @show
        <div class='content'>
            
        </div>
        @yield('content')

    </body>
</html>