<html>
    <head></head>
    <body>
    <h3>Name: {{$name}}</h3>
    <h3>Age: {{$age}}</h3>
    

        


    </body>
</html>