<html>
    <head>
        <title></title>
    </head>
    <body>
        @extends('layout') 
        @section('title','App page') 
        @section('content')
        {{$content}}
        {{$id}}
         
        @endsection
{{-------------- 
        @section('sidenar')
        @parent
        ***chld bar
            
        @endsection
        --}}  

      {{---@section 
        @section('content')
        this is parent content 
        --}}
        {{-----for loop

        @for($i=0;$i<5;$i++)
        {{$i}}
        @endfor
        ---}}
        {{--error
        @include @error('record')
            
        @enderror
        --}}

    </body>
</html>