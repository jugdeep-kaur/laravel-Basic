<html>
    <head></head>
    <body>
        <h1>form</h1>
    <form action="{{url('/getdata')}}" method="post">
        @csrf


        <input type="text" name ="name" placeholder="name">
        <input type="text" name ="age" placeholder="age">
        <input type="submiot" value ="submit">


    </body>
</html>