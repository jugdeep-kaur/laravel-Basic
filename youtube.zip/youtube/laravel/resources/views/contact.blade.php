<html>
    <head>
        <link rel="stylesheet" href="{{asset(asset/css/style.css)}}">
    </head>>
    <body>
        <img src="{{asset('asset/images/mini.jpg')}}">
        <script src="{{asset('asset/js/script.js')}}"></script>
    </body>
</html>