<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class bookController extends Controller
{
    public function show($id){
        $data=['content'=>'thos data','id'=> $id];
        return view('app', $data);
    }
}
