<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class formController extends Controller
{
//to form
public function getForm(){
return view('form');

}
public function getData(Request $request){
    $name= $request->name;
    $age= $request->age;
    $data=['name'=>$name,'age'=>$age];
    return view('data');
    
}
}
